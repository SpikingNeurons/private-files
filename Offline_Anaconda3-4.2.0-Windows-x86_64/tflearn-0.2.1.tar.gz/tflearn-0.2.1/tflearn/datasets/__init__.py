from . import cifar10
from . import imdb
from . import mnist
from . import oxflower17