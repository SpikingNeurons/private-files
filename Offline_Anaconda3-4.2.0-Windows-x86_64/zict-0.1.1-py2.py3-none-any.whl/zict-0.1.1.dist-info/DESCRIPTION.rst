Zict
====

|Build Status|

Mutable Mapping interfaces


