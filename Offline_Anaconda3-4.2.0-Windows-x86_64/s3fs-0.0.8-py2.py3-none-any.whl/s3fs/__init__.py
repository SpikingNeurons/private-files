from .core import S3FileSystem, S3File
from .mapping import S3Map

__version__ = '0.0.8'
