s3fs
====

|Build Status| |Doc Status|

S3FS builds on boto3_ to provide a convenient Python filesystem interface for S3.

View the documentation_ for s3fs.

.. _documentation: http://s3fs.readthedocs.io/en/latest/
.. _boto3: https://boto3.readthedocs.io/en/latest/

.. |Build Status| image:: https://travis-ci.org/dask/s3fs.svg?branch=master
    :target: https://travis-ci.org/dask/s3fs
    :alt: Build Status
.. |Doc Status| image:: http://readthedocs.io/projects/s3fs/badge/?version=latest
    :target: http://s3fs.readthedocs.io/en/latest/?badge=latest
    :alt: Documentation Status


