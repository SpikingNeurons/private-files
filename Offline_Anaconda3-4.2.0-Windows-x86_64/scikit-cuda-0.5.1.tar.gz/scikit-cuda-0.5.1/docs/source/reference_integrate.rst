.. -*- rst -*-

.. currentmodule:: skcuda.integrate

Integration Routines
====================

.. autosummary::
   :toctree: generated/
   :nosignatures:

   trapz
   trapz2d
