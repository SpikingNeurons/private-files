.. -*- rst -*-

.. currentmodule:: skcuda.rlinalg

Randomized Linear Algebra Routines
==================================

.. autosummary::
   :toctree: generated/
   :nosignatures:

   rdmd
   rsvd
