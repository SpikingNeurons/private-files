.. -*- rst -*-

.. currentmodule:: skcuda.special

Special Math Functions
======================
.. autosummary::
   :toctree: generated/
   :nosignatures:

   exp1
   expi
   sici
