.. -*- rst -*-

.. currentmodule:: skcuda.fft

Fast Fourier Transform
======================
.. autosummary::
   :toctree: generated/
   :nosignatures:

   fft
   ifft
   Plan
   
